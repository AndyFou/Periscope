/*-------------------------------------------------------------------------
*
* Copyright (c) 2004-2011, PostgreSQL Global Development Group
*
* IDENTIFICATION
*   $PostgreSQL: pgjdbc/org/postgresql/jdbc2/optional/PoolingDataSource.java,v 1.7 2011/08/02 13:48:35 davecramer Exp $
*
*-------------------------------------------------------------------------
*/
package org.postgresql.jdbc2.optional;

import org.postgresql.ds.PGPoolingDataSource;

public class PoolingDataSource extends PGPoolingDataSource
{
}
